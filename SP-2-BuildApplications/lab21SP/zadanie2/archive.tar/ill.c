#include <stdio.h> 
int main (void) { 
printf ("I like Linux !\n"); return 0; 
} 
